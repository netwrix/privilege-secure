To install the Remove user profile from remote computer Addon into Netwrix Privilege Secure (NPS) you need to:

Copy the Zip file to your NPS Server.
Start a PowerShell console as an Administrator.
Navigate to the folder where you copied the Zip file.
Unzip the file.
Run the install script.

    Expand-Archive -Path .\Remove-UserProfile.Addon.zip -DestinationPath .\Remove-UserProfile.Addon
    cd .\Remove-UserProfile.Addon
    .\Install-Addon.ps1

After installing a new action "Remove user profile from remote computer" will be added to your action list.
