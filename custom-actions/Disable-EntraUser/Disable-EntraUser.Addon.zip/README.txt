To install the Disable EntraID User Addon into Netwrix Privilege Secure (NPS) you need to:

Copy the Zip file to your NPS Server.
Start a PowerShell console as an Administrator.
Navigate to the folder where you copied the Zip file.
Unzip the file.
Run the install script.

    Expand-Archive -Path .\Disable-EntraUser.Addon.zip -DestinationPath .\Disable-EntraUser.Addon
    cd .\Disable-EntraUser.Addon
    .\Install-Addon.ps1

After installing a new action "Disable EntraID User" will be added to your action list.
