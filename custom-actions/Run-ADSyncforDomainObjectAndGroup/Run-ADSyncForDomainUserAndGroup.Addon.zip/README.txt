To install the Run ADSync for User and SingleGroup Addon into Netwrix Privilege Secure (NPS) you need to:

Copy the Zip file to your NPS Server.
Start a PowerShell console as an Administrator.
Navigate to the folder where you copied the Zip file.
Unzip the file.
Run the install script.

    Expand-Archive -Path .\Run-ADSyncForDomainUserAndGroup.Addon.zip -DestinationPath .\Run-ADSyncForDomainUserAndGroup.Addon
    cd .\Run-ADSyncForDomainUserAndGroup.Addon
    .\Install-Addon.ps1

After installing a new action "Run ADSync for User and SingleGroup" will be added to your action list.
